package com.company.Builders;

public enum materialType {
    GOLD,STONE,WOOD;
}
