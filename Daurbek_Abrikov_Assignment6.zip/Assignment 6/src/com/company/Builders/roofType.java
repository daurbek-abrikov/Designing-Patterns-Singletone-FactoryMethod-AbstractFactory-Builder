package com.company.Builders;public enum roofType {
    RECTANGLE_TYPE,TRIANGLE_TYPE;
}
