package com.company.Builders;

public enum garageType {
    BIG_BRIGHT,SMALL_DARK
}
