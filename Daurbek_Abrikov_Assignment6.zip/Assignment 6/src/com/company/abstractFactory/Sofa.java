package com.company.abstractFactory;

public interface Sofa {
    void isComfort();
}
