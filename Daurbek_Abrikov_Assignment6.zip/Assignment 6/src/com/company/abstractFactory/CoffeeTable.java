package com.company.abstractFactory;

public interface CoffeeTable {
    void holdsCoffee();
}
