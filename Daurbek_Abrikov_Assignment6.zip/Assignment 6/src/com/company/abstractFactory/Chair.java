package com.company.abstractFactory;

public interface Chair {
    void hasLegs();
    void sitOn();
}
