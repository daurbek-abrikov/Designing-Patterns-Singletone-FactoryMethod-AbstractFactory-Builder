package com.company.abstractFactory.Victorian;

import com.company.abstractFactory.Sofa;

public class VictorianSofa implements Sofa {
    @Override
    public void isComfort() {
        System.out.println("Victorian sofa is antiquarian and not so comfortable. ");
    }


}
