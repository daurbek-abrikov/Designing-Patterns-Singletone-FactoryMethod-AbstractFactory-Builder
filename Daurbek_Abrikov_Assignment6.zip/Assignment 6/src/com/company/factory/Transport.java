package com.company.factory;

public interface Transport {
    void deliver();
}
