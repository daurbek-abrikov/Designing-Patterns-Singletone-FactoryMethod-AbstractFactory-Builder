package com.company.factory;

public interface Logistics {
    //void PlanDelivery();
    Transport createTransport();
}
